import type { LanguageCode } from '../i18n';
import type { TrafficReportAnalysis } from '@workspace/api-client-react';

export const issueTypes = [
  'Unsafe driving',
  'Speeding',
  'Potholes',
  'Illegal dumping',
  'Streetlight problems',
  'Other',
] as const;

export const frequencies = [
  'One time',
  'A few times',
  'Happens often',
  'Happens every day',
] as const;

export type IssueType = (typeof issueTypes)[number];
export type Frequency = (typeof frequencies)[number];

export type EvidenceImage = {
  name: string;
  type: string;
  size: number;
  objectPath: string;
  previewToken: string;
};

export type StaffEnglishTranslation = {
  location: string;
  approximateTime: string;
  description: string;
};

export type Report = {
  reportId?: string;
  reportNumber: string;
  issueType: IssueType;
  location: string;
  searchedAddress?: string;
  pinLatitude?: number;
  pinLongitude?: number;
  date: string;
  approximateTime: string;
  description: string;
  frequency: Frequency;
  evidence?: EvidenceImage[];
  name?: string;
  email?: string;
  phone?: string;
  submittedAt: string;
  language?: LanguageCode;
  englishTranslation?: StaffEnglishTranslation;
  translationStatus?: 'complete' | 'pending' | 'not-needed';
  analysis?: TrafficReportAnalysis | null;
  analysisStatus?: 'pending' | 'complete' | 'unavailable';
  status?: 'submitted';
};

export type ReportDraft = Omit<
  Report,
  'reportId' | 'reportNumber' | 'submittedAt' | 'language' | 'englishTranslation' | 'translationStatus' | 'analysis' | 'analysisStatus' | 'status'
>;

export const blankDraft: ReportDraft = {
  issueType: '' as IssueType,
  location: '',
  searchedAddress: '',
  pinLatitude: undefined,
  pinLongitude: undefined,
  date: '',
  approximateTime: '',
  description: '',
  frequency: '' as Frequency,
  evidence: [],
  name: '',
  email: '',
  phone: '',
};

export function isEvidenceObjectPath(value: unknown): value is string {
  return typeof value === 'string' && /^\/objects\/evidence\/[a-f0-9-]{36}$/i.test(value);
}

export function isEvidencePreviewToken(value: unknown): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= 2048;
}
